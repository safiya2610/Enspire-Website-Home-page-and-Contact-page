import "./styles.css";

function App() {
  const usr = {
    margin: 150,
    niche: 150,
    mar: 350,

    fontw: 300,
  };

  return (
    <div>
      <nav className="new">
        <div className="icon">
          <img
            src="https://d8it4huxumps7.cloudfront.net/uploads/images/150x150/uploadedManual-64ff7150029d4_logo.png"
            className="logo"
          />
        </div>
        <div className="elements" style={{ width: 900 }}>
          <a href="https://wvtkjp.csb.app/">
            <button>HOME</button>
          </a>
          <a href="https://8xd2kg.csb.app/">
            <button>CONTACT</button>
          </a>

          <button>SPONSORS</button>
          <button>TEAMS</button>
          <button>GALLERY</button>
        </div>
      </nav>
      <div className="body">
        <div className="write">
          <div className="home">
            <div
              className="home-content"
              style={{ marginLeft: usr.margin, marginTop: usr.niche }}
            >
              <h2>E-CELL IIITL PRESENTS</h2>
              <h3>
                <span>E</span>NSPIRE
              </h3>
              <h1>
                Innovation <br />
                Odessey
              </h1>
              <h1 className="prism">Prism of Possibilities</h1>
            </div>
            <div
              className="img"
              style={{ marginRight: usr.mar, marginTop: usr.niche }}
            >
              <img
                src="https://d8it4huxumps7.cloudfront.net/uploads/images/150x150/uploadedManual-64ff7150029d4_logo.png"
                className="ens"
              />
            </div>
          </div>
        </div>
      </div>
      <h1 className="t1">OUR SPONSORS</h1>
      <div className="sponsors">
        <div className="fai">
          <div class="flip-box">
            <div class="flip-box-inner">
              <div class="flip-box-front">
                <img className="mark" />
              </div>
              <div class="flip-box-back"></div>
            </div>
          </div>
        </div>

        <div className="fai">
          <div class="flip-box1">
            <div class="flip-box-inner1">
              <div class="flip-box-front1">
                <img className="mark" />
              </div>
              <div class="flip-box-back1"></div>
            </div>
          </div>
        </div>

        <div className="fai">
          <div class="flip-box2">
            <div class="flip-box-inner2">
              <div class="flip-box-front2">
                <img className="mark" />
              </div>
              <div class="flip-box-back2"></div>
            </div>
          </div>
        </div>
      </div>
      <div className="thirdpage">
        <h1 className="t1">OUR EVENTS</h1>
        <ul class="tilesWrap">
          <li>
            <h2 className="h">01</h2>
            <h5>Million Doller Idea</h5>
            <img
              src="https://scontent.fknu1-1.fna.fbcdn.net/v/t1.6435-9/203338195_113950380915708_1699294898877763423_n.png?stp=dst-png_p843x403&_nc_cat=100&ccb=1-7&_nc_sid=7f8c78&_nc_ohc=As5WSoNBAmoAX8TEfFk&_nc_ht=scontent.fknu1-1.fna&oh=00_AfDo7VNmARf7QecAqmLENjtIHa1y52Tqedc9t6pmtXPkBA&oe=65B3613E"
              alt=""
              className="mdi"
            />
            <button>Read more</button>
          </li>
          <li>
            <h2 className="h">02</h2>
            <h5>Mistry Room</h5>
            <img
              src="https://scontent.fknu1-1.fna.fbcdn.net/v/t1.6435-9/205627990_116413477336065_726511509651954305_n.png?stp=dst-png_p843x403&_nc_cat=100&ccb=1-7&_nc_sid=7f8c78&_nc_ohc=ZQt1MNnLZBoAX953sRG&_nc_ht=scontent.fknu1-1.fna&oh=00_AfAU_6RcgE-5kYm8XIVbt9h4MZUq8-YIWpZFhGmV75g4fg&oe=65B342D6"
              alt=""
              className="mistry"
            />
            <button>Read more</button>
          </li>
          <li>
            <h2 className="h">03</h2>
            <h5>Find X ?</h5>
            <img
              src="https://scontent.fknu1-5.fna.fbcdn.net/v/t1.6435-9/200960559_116078160702930_5889375979258483869_n.jpg?stp=dst-jpg_p843x403&_nc_cat=106&ccb=1-7&_nc_sid=dd63ad&_nc_ohc=dbIu6bTkh2wAX87H5Gh&_nc_ht=scontent.fknu1-5.fna&oh=00_AfAYYuzGY66rOcA19S7Ff1uYC5Iq9f_woHGJlfrc5RoTIQ&oe=65B351E9"
              className="findx"
            />
            <button>Read more</button>
          </li>
          <li>
            <h2 className="h">04</h2>
            <h5>IPL Auction</h5>
            <img
              src="https://scontent.fknu1-6.fna.fbcdn.net/v/t1.6435-9/196478405_116167524027327_4506452580473627466_n.png?stp=dst-png_p843x403&_nc_cat=102&ccb=1-7&_nc_sid=7f8c78&_nc_ohc=EnlrMb5H2j0AX--SFOi&_nc_ht=scontent.fknu1-6.fna&oh=00_AfBOV1FsNrdzqnMSjrY8IrN-WWj_VLOBBBwDiOfVnUod-w&oe=65B34C23"
              alt=""
              className="crazy"
            />
            <button>Read more</button>
          </li>
        </ul>
      </div>
      <div className="overallcube">
        <div class="cube">
          <div class="box box1">
            <img
              src="https://edtimes.in/wp-content/uploads/2023/02/319844405_2206227626213988_6256471654661609004_n-1.jpg"
              alt="image 1"
              className="u"
            />
          </div>

          <div class="box box2">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-SDneLt87ixqZrH3jS5IRjxbGCZCdH6-n-g&usqp=CAU"
              alt="image 2"
              className="u"
            />
          </div>

          <div class="box box3">
            <img
              src="https://scontent.flko9-2.fna.fbcdn.net/v/t1.6435-9/44891541_1951771498244148_2892474351448227840_n.png?stp=dst-png_p843x403&_nc_cat=101&ccb=1-7&_nc_sid=7f8c78&_nc_ohc=vYk8Wm1R4NEAX8S4t4x&_nc_oc=AQnQ6lGZMH-FoA867FgtN5gkJK7AWU2Slx8e7f_SjHyQ0qhUnLAyNOptxvR0J4ulCoRmST281RNEvNk6J5fAItrb&_nc_ht=scontent.flko9-2.fna&oh=00_AfCaQ382X4vXVWTRuFRrdhk2ZCivql3yOKaqEim76gNRPg&oe=65B493C4"
              alt="image 3"
              className="u"
            />
          </div>

          <div class="box box4">
            <img
              src="https://enspire-iiitl.netlify.app/assets/img/ADmad.webp"
              alt="image 4"
              className="u"
            />
          </div>

          <div class="box box5">
            <img
              src="https://enspire-22.vercel.app/WinOnStockPe.jpeg"
              alt="image 5"
              className="u"
            />
          </div>

          <div class="box box6">
            <img
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDkW4x7WEeHEU3qlJ-6__4a95j4zoX_J87Wg&usqp=CAU"
              alt="image 6"
              className="u"
            />
          </div>
        </div>
        <div className="poster">
          <img
            src="https://enspire.netlify.app/Posters/Coding.png?imwidth=640"
            alt=""
            className="pos"
          />
        </div>
      </div>

      <div className="merch">
        <div className="mer1">
          <h1 className="mer">EXCLUSIVE MERCH</h1>
          <h5 style={{ fontWeight: usr.fontw }}>
            Get exclusive Enspire merch with custom,
            <br /> handmade pieces from right here
          </h5>
          <br />
          <button className="merchbtn">Buy Merch</button>
        </div>
        <div className="mer2">
          <img
            src="https://enspire.netlify.app/Posters/Untitled%20design%20(1).png?imwidth=2048"
            className="shirt"
          />
        </div>
      </div>
    </div> //overall
  );
}

export default App;
